# Teradata Welcome Agent

A dependency-free AgentOps demonstration agent. It does not call an LLM.

## Local test

```bash
cd teradata_welcome_agent
python test_agent.py
```

Expected output:

```text
welcome to teradata
```

## Import into AgentOps

Upload `../teradata_welcome_agent.zip`. The files are stored at the root of the
archive so AgentOps can discover `agent.py` and `config.yaml`.
