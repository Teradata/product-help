import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from agent_runtime import AgentRuntimeApp, AuthContext
from customer_agent import create_custom_agent

app = AgentRuntimeApp()


@app.entrypoint
async def invoke(message, auth_context: AuthContext, streaming=True):
    del auth_context, streaming
    agent = create_custom_agent()
    return await agent.run(message)
