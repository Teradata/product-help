import json
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Dict, Optional


@dataclass(frozen=True)
class AuthContext:
    token: Optional[str] = None


Entrypoint = Callable[..., Awaitable[Any]]


class AgentRuntimeApp:
    """Minimal local ASGI runtime compatible with the AgentOps entrypoint pattern."""

    def __init__(self) -> None:
        self._entrypoint: Optional[Entrypoint] = None

    def entrypoint(self, function: Entrypoint) -> Entrypoint:
        self._entrypoint = function
        return function

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http":
            raise RuntimeError("The agent runtime only supports HTTP requests.")

        path = scope.get("path", "")
        method = scope.get("method", "GET")

        if path == "/health" and method == "GET":
            await self._respond(send, 200, {"status": "ok"})
            return

        if path != "/invoke" or method != "POST":
            await self._respond(send, 404, {"detail": "Not found"})
            return

        if self._entrypoint is None:
            await self._respond(send, 500, {"detail": "No entrypoint registered"})
            return

        payload = await self._read_json(receive)
        message = payload.get("message")
        if not isinstance(message, str):
            await self._respond(
                send, 400, {"detail": "The 'message' field must be a string"}
            )
            return

        auth_header = self._get_header(scope, "authorization")
        token = auth_header.removeprefix("Bearer ").strip() if auth_header else None
        result = await self._entrypoint(
            message=message,
            auth_context=AuthContext(token=token),
            streaming=bool(payload.get("streaming", True)),
        )
        await self._respond(send, 200, result)

    @staticmethod
    def _get_header(scope, name: str) -> Optional[str]:
        expected = name.encode("latin-1")
        for header_name, value in scope.get("headers", []):
            if header_name.lower() == expected:
                return value.decode("latin-1")
        return None

    @staticmethod
    async def _read_json(receive) -> Dict[str, Any]:
        body = b""
        more_body = True
        while more_body:
            event = await receive()
            if event["type"] != "http.request":
                continue
            body += event.get("body", b"")
            more_body = event.get("more_body", False)

        if not body:
            return {}

        value = json.loads(body)
        if not isinstance(value, dict):
            raise TypeError("The request body must be a JSON object.")
        return value

    @staticmethod
    async def _respond(send, status: int, value: Any) -> None:
        body = json.dumps(value).encode("utf-8")
        await send(
            {
                "type": "http.response.start",
                "status": status,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode("ascii")),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body})
