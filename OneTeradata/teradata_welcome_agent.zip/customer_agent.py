class WelcomeAgent:
    async def run(self, message: str) -> str:
        if message.strip().casefold() == "hi":
            return "welcome to teradata"

        return "Please say hi."


def create_custom_agent() -> WelcomeAgent:
    return WelcomeAgent()
