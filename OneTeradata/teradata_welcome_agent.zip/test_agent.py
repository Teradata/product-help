import asyncio
import json

from agent import app, invoke
from agent_runtime import AuthContext


async def invoke_over_asgi(message: str) -> str:
    request = json.dumps({"message": message}).encode("utf-8")
    events = [
        {"type": "http.request", "body": request, "more_body": False}
    ]
    responses = []

    async def receive():
        return events.pop(0)

    async def send(event):
        responses.append(event)

    await app(
        {
            "type": "http",
            "method": "POST",
            "path": "/invoke",
            "headers": [],
        },
        receive,
        send,
    )
    return json.loads(responses[-1]["body"])


async def main() -> None:
    response = await invoke("hi", AuthContext())
    assert response == "welcome to teradata", response
    assert await invoke_over_asgi("hi") == response
    print(response)


if __name__ == "__main__":
    asyncio.run(main())
